const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET = "clave_secreta";

// 🔌 conexión MySQL
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "0115Riveros",
    database: "microgasto"
});

db.connect(err => {
    if (err) console.log(err);
    else console.log("MySQL conectado ✅");
});


/* =========================
   📝 REGISTRO
========================= */
app.post("/registro", (req, res) => {
    let { email, password } = req.body;

    email = email.trim().toLowerCase();

    const check = "SELECT * FROM usuarios WHERE email = ?";

    db.query(check, [email], async (err, result) => {
        if (err) return res.status(500).json({ success: false });

        if (result.length > 0) {
            return res.json({
                success: false,
                mensaje: "Usuario ya existe ❌"
            });
        }

        const hash = await bcrypt.hash(password, 10);

        const sql = "INSERT INTO usuarios (email, password) VALUES (?, ?)";

        db.query(sql, [email, hash], (err) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ success: false });
            }

            res.json({
                success: true,
                mensaje: "Usuario registrado ✅"
            });
        });
    });
});


/* =========================
   🔐 LOGIN
========================= */
app.post("/login", (req, res) => {
    let { email, password } = req.body;

    email = email.trim().toLowerCase();

    const sql = "SELECT * FROM usuarios WHERE email = ?";

    db.query(sql, [email], async (err, result) => {

        if (err) {
            console.log(err);
            return res.status(500).json({
                success: false,
                mensaje: "Error servidor"
            });
        }

        if (result.length === 0) {
            return res.json({
                success: false,
                mensaje: "Usuario no existe ❌"
            });
        }

        const usuario = result[0];

        // 🔥 DEBUG
        console.log("LOGIN:", email);
        console.log("PASS INGRESADA:", password);
        console.log("PASS BD:", usuario.password);

        const valido = await bcrypt.compare(password, usuario.password);

        if (!valido) {
            return res.json({
                success: false,
                mensaje: "Contraseña incorrecta ❌"
            });
        }

        const token = jwt.sign(
            { id: usuario.id, email: usuario.email },
            SECRET,
            { expiresIn: "1h" }
        );

        res.json({
            success: true,
            token,
            mensaje: "Login correcto ✅"
        });
    });
});


/* =========================
   🔒 TOKEN
========================= */
function verificarToken(req, res, next) {
    let token = req.headers["authorization"];

    if (!token) {
        return res.status(403).json({ mensaje: "No token" });
    }

    if (token.startsWith("Bearer ")) {
        token = token.slice(7);
    }

    jwt.verify(token, SECRET, (err, data) => {
        if (err) {
            return res.status(403).json({ mensaje: "Token inválido" });
        }

        req.usuario = data;
        next();
    });
}


/* =========================
   💰 GASTOS
========================= */
app.post("/gastos", verificarToken, (req, res) => {
    const { categoria, monto, descripcion } = req.body;
    const usuario_id = req.usuario.id;

    const sql = "INSERT INTO gastos (usuario_id, categoria, monto, descripcion) VALUES (?, ?, ?, ?)";

    db.query(sql, [usuario_id, categoria, monto, descripcion], (err) => {
        if (err) return res.json({ success: false });

        res.json({ success: true });
    });
});

app.get("/gastos", verificarToken, (req, res) => {
    const usuario_id = req.usuario.id;

    db.query(
        "SELECT * FROM gastos WHERE usuario_id = ? ORDER BY id DESC",
        [usuario_id],
        (err, result) => {
            if (err) return res.json([]);

            res.json(result);
        }
    );
});

app.delete("/gastos/:id", verificarToken, (req, res) => {
    const { id } = req.params;
    const usuario_id = req.usuario.id;

    db.query(
        "DELETE FROM gastos WHERE id = ? AND usuario_id = ?",
        [id, usuario_id],
        () => res.json({ success: true })
    );
});

app.put("/gastos/:id", verificarToken, (req, res) => {
    const { id } = req.params;
    const { categoria, monto, descripcion } = req.body;
    const usuario_id = req.usuario.id;

    db.query(
        `UPDATE gastos 
         SET categoria=?, monto=?, descripcion=? 
         WHERE id=? AND usuario_id=?`,
        [categoria, monto, descripcion, id, usuario_id],
        () => res.json({ success: true })
    );
});

app.listen(3000, () => console.log("Servidor en puerto 3000 🚀"));