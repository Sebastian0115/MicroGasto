document.getElementById("formGasto").addEventListener("submit", function(e) {
    e.preventDefault();

    const categoria = document.getElementById("categoria").value;
    const cantidad = document.getElementById("cantidad").value;

    const gasto = {
        categoria,
        cantidad: parseFloat(cantidad)
    };

    let gastos = JSON.parse(localStorage.getItem("gastos")) || [];
    gastos.push(gasto);

    localStorage.setItem("gastos", JSON.stringify(gastos));

    alert("Gasto guardado ✅");
});