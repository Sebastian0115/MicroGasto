// 🔐 LOGIN
function login(e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

    // 🔍 Buscar usuario
    const usuario = usuarios.find(u => u.email === email);

    // ❌ Usuario no existe
    if (!usuario) {
        alert("Usuario no existe ❌");
        return;
    }

    // ❌ Contraseña incorrecta
    if (usuario.password !== password) {
        alert("Contraseña incorrecta ❌");
        return;
    }

    // ✅ Login correcto
    localStorage.setItem("usuarioActivo", JSON.stringify(usuario));

    alert("Login exitoso ✅");

    window.location.href = "dashboard.html";
}


// 📝 REGISTRO
function registrarUsuario(e) {

    e.preventDefault();

    const nombre = document.getElementById("nombre").value;

    const email = document.getElementById("email").value;

    const password = document.getElementById("password").value;

    const confirmar = document.getElementById("confirmar").value;

    // VALIDAR CONTRASEÑAS

    if(password !== confirmar){

        alert("Las contraseñas no coinciden ❌");
        return;
    }

    // OBTENER USUARIOS

    let usuarios = JSON.parse(
        localStorage.getItem("usuarios")
    ) || [];

    // VALIDAR SI EXISTE

    const existe = usuarios.find(
        u => u.email === email
    );

    if(existe){

        alert("El usuario ya existe ❌");
        return;
    }

    // CREAR USUARIO

    const nuevoUsuario = {

    id: Date.now(),
    nombre,
    email,
    password
};

    usuarios.push(nuevoUsuario);

    localStorage.setItem(
        "usuarios",
        JSON.stringify(usuarios)
    );

    alert("Usuario registrado ✅");

    window.location.href = "index.html";
}

// 💰 GUARDAR GASTO (LOCAL)
function guardarGasto(e) {
    e.preventDefault();

    const usuario = JSON.parse(localStorage.getItem("usuarioActivo"));

    const categoria = document.getElementById("categoria").value;
    const monto = document.getElementById("monto").value;
    const descripcion = document.getElementById("descripcion").value;

    const gasto = {
        id: Date.now(),
        categoria,
        monto,
        descripcion,
        fecha: new Date().toISOString()
    };

    let gastos = JSON.parse(localStorage.getItem("gastos_" + usuario.id)) || [];

    gastos.push(gasto);

    localStorage.setItem("gastos_" + usuario.id, JSON.stringify(gastos));

    alert("Gasto guardado ✅");

    window.location.href = "dashboard.html";
}

function mostrarGastos() {

    const usuario =
    JSON.parse(localStorage.getItem("usuarioActivo"));

    if(!usuario) return;

    let gastos =
    JSON.parse(localStorage.getItem("gastos_" + usuario.id))
    || [];

    const lista =
    document.getElementById("listaGastos");

    if(!lista) return;

    lista.innerHTML = "";

    gastos.forEach(g => {

        const li = document.createElement("li");

        li.innerHTML = `
            <strong>${g.categoria}</strong>
            - $${g.monto}
            <br>
            <small>${g.descripcion}</small>
        `;

        lista.appendChild(li);

    });

}

mostrarGastos();

/* SLIDER AUTOMÁTICO */

const slides = document.querySelectorAll('.slide');

let index = 0;

setInterval(() => {

    if(slides.length === 0) return;

    slides[index].classList.remove('active');

    index++;

    if(index >= slides.length){
        index = 0;
    }

    slides[index].classList.add('active');

}, 4000);
