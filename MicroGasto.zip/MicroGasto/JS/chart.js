const gastos = JSON.parse(localStorage.getItem("gastos")) || [];

let categorias = {};
gastos.forEach(g => {
    categorias[g.categoria] = (categorias[g.categoria] || 0) + g.cantidad;
});

const data = {
    labels: Object.keys(categorias),
    datasets: [{
        label: 'Gastos',
        data: Object.values(categorias)
    }]
};

const config = {
    type: 'pie',
    data: data
};

new Chart(
    document.getElementById('grafica'),
    config
);