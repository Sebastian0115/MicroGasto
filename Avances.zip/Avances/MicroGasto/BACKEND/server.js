const express = require("express");
const cors = require("cors");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const app = express();

app.use(cors());
app.use(express.json());

// 🔌 conexión MySQL
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "0115Riveros", // tu contraseña
    database: "microgasto"
});

db.connect(err => {
    if (err) console.log(err);
    else console.log("MySQL conectado ✅");
});

// 🔐 clave JWT
const SECRET = "clave_secreta";

// 📝 REGISTRO
app.post("/registro", async (req, res) => {
    const { email, password } = req.body;

    const bcrypt = require("bcrypt");
    const hash = await bcrypt.hash(password, 10);

    const sql = "INSERT INTO usuarios (email, password) VALUES (?, ?)";

    db.query(sql, [email, hash], (err, result) => {
        if (err) {
            console.log("ERROR SQL:", err);
            return res.json({ success: false });
        }

        res.json({ success: true, mensaje: "Usuario registrado" });
    });
});

// 🔐 LOGIN
app.post("/login", (req, res) => {
    const { email, password } = req.body;

    const sql = "SELECT * FROM usuarios WHERE email = ?";

    db.query(sql, [email], async (err, result) => {
        if (result.length === 0) {
            return res.json({ success: false });
        }

        const usuario = result[0];

        const valido = await bcrypt.compare(password, usuario.password);

        if (!valido) {
            return res.json({ success: false });
        }

        const token = jwt.sign(
            { id: usuario.id, email: usuario.email },
            SECRET,
            { expiresIn: "1h" }
        );

        res.json({ success: true, token });
    });
});

// 📝 GUARDAR GASTO
app.post("/gastos", verificarToken, (req, res) => { 
    console.log("BODY:", req.body);
    console.log("USUARIO:", req.usuario);
   

    const { categoria, monto, descripcion } = req.body;
    const usuario_id = req.usuario.id;

    const sql = "INSERT INTO gastos (usuario_id, categoria, monto, descripcion) VALUES (?, ?, ?, ?)";

    db.query(sql, [usuario_id, categoria, monto, descripcion], (err, result) => {
        if (err) {
            console.log("ERROR SQL:", err);
            return res.json({ success: false });
        }

        res.json({ success: true });
    });
});

function verificarToken(req, res, next) {
    let token = req.headers["authorization"];

    if (!token) {
        console.log("❌ No hay token");
        return res.status(403).json({ error: "No token" });
    }

    // 🔥 limpiar "Bearer "
    if (token.startsWith("Bearer ")) {
        token = token.slice(7);
    }

    if (!token) {
        console.log("❌ Token vacío");
        return res.status(403).json({ error: "Token vacío" });
    }

    jwt.verify(token, SECRET, (err, data) => {
        if (err) {
            console.log("❌ Token inválido");
            return res.status(403).json({ error: "Token inválido" });
        }

        req.usuario = data;
        next();
    });
}

// 📊 prueba protegida
app.get("/gastos", verificarToken, (req, res) => {
    const usuario_id = req.usuario.id;

    const sql = "SELECT * FROM gastos WHERE usuario_id = ?";

    db.query(sql, [usuario_id], (err, result) => {
        if (err) {
            console.log(err);
            return res.json([]);
        }

        res.json(result);
    });
});

app.listen(3000, () => console.log("Servidor en puerto 3000"));

// 📊 OBTENER GASTOS DEL USUARIO
app.get("/gastos", verificarToken, (req, res) => {
    const usuario_id = req.usuario.id;

    const sql = "SELECT * FROM gastos WHERE usuario_id = ?";

    db.query(sql, [usuario_id], (err, result) => {
        if (err) {
            console.log(err);
            return res.json([]);
        }

        res.json(result);
    });
});

app.listen(3000, () => {
    console.log("Servidor en puerto 3000 🚀");
});

// 🗑️ ELIMINAR GASTO
app.delete("/gastos/:id", verificarToken, (req, res) => {
    const { id } = req.params;
    const usuario_id = req.usuario.id;

    const sql = "DELETE FROM gastos WHERE id = ? AND usuario_id = ?";

    db.query(sql, [id, usuario_id], (err, result) => {
        if (err) {
            console.log(err);
            return res.json({ success: false });
        }

        res.json({ success: true });
    });
});

// ✏️ EDITAR GASTO
app.put("/gastos/:id", verificarToken, (req, res) => {
    const { id } = req.params;
    const { categoria, monto, descripcion } = req.body;
    const usuario_id = req.usuario.id;

    const sql = `
        UPDATE gastos 
        SET categoria = ?, monto = ?, descripcion = ?
        WHERE id = ? AND usuario_id = ?
    `;

    db.query(sql, [categoria, monto, descripcion, id, usuario_id], (err) => {
        if (err) {
            console.log(err);
            return res.json({ success: false });
        }

        res.json({ success: true });
    });
});