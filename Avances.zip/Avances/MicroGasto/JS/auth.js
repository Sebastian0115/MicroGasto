// 🔐 LOGIN
async function login(e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try {
        const res = await fetch("http://localhost:3000/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        console.log("LOGIN:", data);

    if (data.success) {
    localStorage.setItem("token", data.token);

    // ✅ guardar mensaje
    localStorage.setItem("mensaje", "Inicio de sesión exitoso ✅");

    window.location.href = "dashboard.html";
} 
    else {
            alert("Error en login ❌");
        }

    } catch (error) {
        console.error(error);
        alert("No conecta con el servidor ❌");
    }
}


// 📝 REGISTRO
async function registrar(e) {
    e.preventDefault();

    const email = document.getElementById("newEmail").value;
    const password = document.getElementById("newPassword").value;

    try {
        const res = await fetch("http://localhost:3000/registro", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();

        console.log("REGISTRO:", data);

        if (data.success) {
            alert("Usuario registrado ✅");
            window.location.href = "index.html";
        } else {
            alert("Error ❌");
        }

    } catch (error) {
        console.error(error);
        alert("No conecta con el servidor ❌");
    }
}

async function guardarGasto(e) {
    e.preventDefault();

    const categoria = document.getElementById("categoria").value;
    const monto = document.getElementById("monto").value;
    const descripcion = document.getElementById("descripcion").value;

    console.log("DATOS:", categoria, monto, descripcion); // 👈 AGREGA ESTO

    const token = localStorage.getItem("token");

    try {
        const res = await fetch("http://localhost:3000/gastos", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": token
            },
            body: JSON.stringify({
                categoria,
                monto,
                descripcion
            })
        });

        const data = await res.json();

        console.log("RESPUESTA:", data);

        if (data.success) {
            alert("Gasto guardado ✅");
        } else {
            alert("Error ❌");
        }

    } catch (error) {
        console.error(error);
        alert("Error de conexión ❌");
    }
}

